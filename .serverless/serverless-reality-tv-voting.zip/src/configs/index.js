const Request = require('./request.config');
const Ddb = require('./ddb.config');
module.exports = {
  Request,
  Ddb
}