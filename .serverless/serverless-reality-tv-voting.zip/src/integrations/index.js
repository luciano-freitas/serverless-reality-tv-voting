const ViaCepIntegration = require('./via-cep.integration');

module.exports = {
  ViaCepIntegration
}