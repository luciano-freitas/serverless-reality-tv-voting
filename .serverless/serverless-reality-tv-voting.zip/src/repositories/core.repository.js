const { Ddb } = require('../configs');

const CoreRepository = {

  async create(table, item) {
    const timestamp = new Date().getTime();
    const data = {
      ...item,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    const params = {
      TableName: table,
      Item: data
    };

    return Ddb.ddbClient.put(params).promise().then(() => data);
  },

  async update(table, structure) {
    const params = {
      ...structure,
      TableName: table,
      ReturnValues: 'ALL_NEW',
    };

    return Ddb.ddbClient.update(params).promise();
  }
}

module.exports = CoreRepository;