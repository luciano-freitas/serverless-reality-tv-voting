const CoreRepository = require('./core.repository');
const UserRepository = require('./user.repository');

module.exports = {
  CoreRepository,
  UserRepository
}