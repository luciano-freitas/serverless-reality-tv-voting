const CoreRepository = require('./core.repository');
const TABLE = process.env.DYNAMODB_TABLE_USERS;

const UserRepository = {

  async create(item) {
    return CoreRepository.create(TABLE, item);
  },

  async update(keys, item) {
    const structure = {
      Key: {
        documentNumber: keys.documentNumber,
      },
      ExpressionAttributeNames: {
        '#name': 'name',
        '#updatedAt': 'updatedAt',
        '#addresses': 'addresses',
      },
      ExpressionAttributeValues: {
        ':name': item.name,
        ':addreses': item.addresses,
        ':updatedAt': Date.now(),
      },
      UpdateExpression: 'SET #name = :name, #updatedAt = :updatedAt, #addresses = :addresses',
    }

    return CoreRepository.update(TABLE, structure);
  }

}

module.exports = UserRepository;