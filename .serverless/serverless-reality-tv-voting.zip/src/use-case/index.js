const UsersUseCase = require('./users.use-case');

module.exports = {
  UsersUseCase
}